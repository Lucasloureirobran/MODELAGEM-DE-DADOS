import java.util.Scanner;

public class Main {
    static int permicao(int idade){
        
        if (idade >= 18){ 
        System.out.println("Entrada liberada!");
        }else{
         System.out.println("Entrada impedida!");
        } 
        
        return idade;
    }
    public static void main(String[] args) {
        Scanner ent = new Scanner(System.in);
        System.out.println("********PERMIÇÃO********");
        System.out.println("Digite sua idade:\n");
        int idade= ent.nextInt();
        permicao(idade);
       
    }
}